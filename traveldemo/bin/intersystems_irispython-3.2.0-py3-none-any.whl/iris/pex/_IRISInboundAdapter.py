class _IRISInboundAdapter:
    """ Class for proxy objects that represent inbound adapter instances in IRIS."""
    
    def __init__(self):
        self.irisHandle = None